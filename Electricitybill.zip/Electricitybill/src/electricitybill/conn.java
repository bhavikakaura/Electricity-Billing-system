/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package electricitybill;

/**
 *
 * @author Bhavika kaura
 */
import java.sql.*;  
import java.sql.DriverManager;
public class conn{
    Connection c;
    Statement s;
    public conn(){  
        try{  
            Class.forName("com.mysql.cj.jdbc.Driver");  
            c =DriverManager.getConnection("jdbc:mysql://localhost:3306/project6","root","");    
            s =c.createStatement();  
            System.out.println("connection");
           
        }catch(Exception e){ 
            System.out.println(e);
        }  
    }
     public static void main(String[] args) 
    {
     new conn();   
    }
} 